import CartIcon from "./icons/CartIcon.jsx"
import SearchIcon from "./icons/SearchIcon.jsx"

export { CartIcon, SearchIcon }